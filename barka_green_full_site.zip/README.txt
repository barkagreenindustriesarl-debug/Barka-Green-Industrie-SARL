Remplacez les images dans assets/images par vos photos produit. Le fichier index.html est la page principale.
